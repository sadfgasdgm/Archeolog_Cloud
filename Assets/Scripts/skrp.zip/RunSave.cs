using UnityEngine;

// Автосохранение текущего прохождения экспедиции (ТЗ 2.9).
// Ext   - находка/фрагмент принят (успешно извлечён), хранится сохранность;
// Clean - принятая находка очищена на столе;
// Assembled - табличка собрана.
// Ключи привязаны к выбранной зоне (SelectedZone), чтобы прогресс одной зоны не попадал в другую.
// Коллекция (ItemInt_*) хранится отдельно и не зависит от текущего прохождения,
// поэтому «Повторить экспедицию» всегда начинается заново, а «Продолжить» - с места сохранения.
public static class RunSave
{
    // префикс текущей зоны: Z0_, Z1_, ...
    static string Z => "Z" + PlayerPrefs.GetInt("SelectedZone", 0) + "_";

    static float Get(string key) => PlayerPrefs.GetFloat(Z + key, -1f);
    static void Set(string key, float v) { PlayerPrefs.SetFloat(Z + key, Mathf.Max(0f, v)); PlayerPrefs.Save(); }

    public static bool HasExt(ArtifactKind k) => Get("RunExt_" + k) >= 0f;
    public static float GetExt(ArtifactKind k) => Mathf.Max(0f, Get("RunExt_" + k));
    public static void SetExt(ArtifactKind k, float v) => Set("RunExt_" + k, v);

    public static bool HasClean(ArtifactKind k) => Get("RunClean_" + k) >= 0f;
    public static float GetClean(ArtifactKind k) => Mathf.Max(0f, Get("RunClean_" + k));
    public static void SetClean(ArtifactKind k, float v) => Set("RunClean_" + k, v);

    public static bool HasAssembled => Get("RunAssembled") >= 0f;
    public static float GetAssembled() => Mathf.Max(0f, Get("RunAssembled"));
    public static void SetAssembled(float v) => Set("RunAssembled", v);

    // начало нового прохождения: принятые находки и отметки точек сбрасываются
    public static void Clear()
    {
        foreach (var k in new[] { ArtifactKind.Bowl, ArtifactKind.TabletLeft, ArtifactKind.TabletRight })
        {
            PlayerPrefs.DeleteKey(Z + "RunExt_" + k);
            PlayerPrefs.DeleteKey(Z + "RunClean_" + k);
        }
        PlayerPrefs.DeleteKey(Z + "RunAssembled");

        // отметки точек интереса (ключи задаёт ScanPoint.cs, поэтому здесь они без префикса зоны)
        PlayerPrefs.DeleteKey("Found_ScanPoint");
        for (int i = 1; i <= 4; i++)
        {
            PlayerPrefs.DeleteKey("Found_ScanPoint_" + i);
            for (int copy = 1; copy <= 20; copy++)
                PlayerPrefs.DeleteKey("Found_ScanPoint_" + i + " (" + copy + ")");
        }
        PlayerPrefs.Save();
    }
}
