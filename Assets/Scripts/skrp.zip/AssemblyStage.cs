using UnityEngine;
using UnityEngine.EventSystems;

// Восстановление из двух фрагментов (ТЗ): перетаскивание, поворот кнопками ±15°,
// подсветка подходящих граней, автосоединение при допуске 0,15 ед. и 15°.
// Создаётся из LabStation.
public class AssemblyStage : MonoBehaviour
{
    public bool Done { get; private set; }

    const float W = 1.0f;          // ширина половинки = расстояние между центрами в собранном виде
    const float DistTol = 0.15f;   // допуск по расстоянию
    const float AngTol = 15f;      // допуск по углу

    Camera cam;
    Transform a, b, selected;
    Renderer edgeA, edgeB, bodyA, bodyB;
    Plane plane;
    Vector3 grabOffset;
    bool dragging;

    static readonly Color Stone = new Color(0.62f, 0.61f, 0.56f);
    static readonly Color StoneSel = new Color(0.80f, 0.78f, 0.66f);
    static readonly Color EdgeIdle = new Color(0.25f, 0.22f, 0.18f);
    static readonly Color EdgeGlow = new Color(1f, 0.7f, 0.1f);

    public void Init(Camera c)
    {
        cam = c;
        plane = new Plane(Vector3.up, transform.position);

        a = MakePiece("FragmentA", new Vector3(-1.5f, 0f, -0.3f), 25f, -1f, out bodyA, out edgeA);
        b = MakePiece("FragmentB", new Vector3(1.6f, 0f, 0.5f), -55f, 1f, out bodyB, out edgeB);
        selected = b;
        Paint();
    }

    // половинка: корень без масштаба + тело + полоска «линии разлома» на внутренней грани
    Transform MakePiece(string name, Vector3 localPos, float yaw, float edgeSide, out Renderer body, out Renderer edge)
    {
        var root = new GameObject(name).transform;
        root.SetParent(transform, false);
        root.localPosition = localPos;
        root.localRotation = Quaternion.Euler(0f, yaw, 0f);

        var m = GameObject.CreatePrimitive(PrimitiveType.Cube);
        m.name = "Body";
        m.transform.SetParent(root, false);
        m.transform.localScale = new Vector3(W, 0.18f, 1.3f);
        body = m.GetComponent<Renderer>();
        body.material = Mats.Make(Stone, 0.1f);

        // A: стык справа (+x), B: стык слева (-x)
        var e = GameObject.CreatePrimitive(PrimitiveType.Cube);
        e.name = "Edge";
        e.transform.SetParent(root, false);
        e.transform.localScale = new Vector3(0.07f, 0.2f, 1.3f);
        e.transform.localPosition = new Vector3(-edgeSide * W * 0.5f, 0f, 0f);
        Destroy(e.GetComponent<Collider>());
        edge = e.GetComponent<Renderer>();
        edge.material = Mats.Make(EdgeIdle, 0.1f);
        return root;
    }

    public void Rotate(float deg)
    {
        if (Done || selected == null) return;
        selected.Rotate(0f, deg, 0f, Space.World);
    }

    static bool OverUI()
    {
        if (EventSystem.current == null) return false;
        return Input.touchCount > 0
            ? EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId)
            : EventSystem.current.IsPointerOverGameObject();
    }

    void Update()
    {
        if (Time.timeScale == 0f || cam == null || Done) return;

        if (Input.GetMouseButtonDown(0) && !OverUI())
        {
            if (Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out RaycastHit hit, 30f))
            {
                var root = hit.collider.transform.parent;
                if (root == a || root == b)
                {
                    selected = root;
                    dragging = true;
                    if (plane.Raycast(cam.ScreenPointToRay(Input.mousePosition), out float d0))
                        grabOffset = selected.position - cam.ScreenPointToRay(Input.mousePosition).GetPoint(d0);
                    Paint();
                }
            }
        }

        if (dragging && Input.GetMouseButton(0))
        {
            var ray = cam.ScreenPointToRay(Input.mousePosition);
            if (plane.Raycast(ray, out float d))
            {
                Vector3 p = ray.GetPoint(d) + grabOffset;
                var o = transform.position;
                p.x = Mathf.Clamp(p.x, o.x - 3.2f, o.x + 3.2f);
                p.z = Mathf.Clamp(p.z, o.z - 2.1f, o.z + 2.1f);
                p.y = o.y;
                selected.position = p;
            }
        }
        if (Input.GetMouseButtonUp(0)) dragging = false;

        Check();
    }

    void Check()
    {
        // положение B в системе координат A: в собранном виде это (W, 0, 0)
        Vector3 rel = a.InverseTransformPoint(b.position);
        float dist = Vector2.Distance(new Vector2(rel.x, rel.z), new Vector2(W, 0f));
        float ang = Mathf.Abs(Mathf.DeltaAngle(a.eulerAngles.y, b.eulerAngles.y));

        // подсветка граней при приближении
        bool near = dist < 0.7f && ang < 45f;
        SetColor(edgeA.material, near ? EdgeGlow : EdgeIdle);
        SetColor(edgeB.material, near ? EdgeGlow : EdgeIdle);

        if (dist <= DistTol && ang <= AngTol)
        {
            // соединение: фиксируем B точно на месте
            b.position = a.TransformPoint(new Vector3(W, 0f, 0f));
            b.rotation = a.rotation;
            b.SetParent(a, true);
            SetColor(edgeA.material, EdgeIdle);
            SetColor(edgeB.material, EdgeIdle);
            edgeA.gameObject.SetActive(false);
            edgeB.gameObject.SetActive(false);
            selected = a;
            Paint();
            Done = true;
        }
    }

    void Paint()
    {
        SetColor(bodyA.material, selected == a ? StoneSel : Stone);
        SetColor(bodyB.material, selected == b ? StoneSel : Stone);
    }

    static void SetColor(Material m, Color c)
    {
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
        if (m.HasProperty("_Color")) m.SetColor("_Color", c);
    }
}
