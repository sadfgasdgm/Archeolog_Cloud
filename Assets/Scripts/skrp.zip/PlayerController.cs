using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [SerializeField] VirtualJoystick joystick;
    [SerializeField] Transform cam;
    [SerializeField] float walkSpeed = 2f;    // Скорость ходьбы
    [SerializeField] float fastSpeed = 3f;    // Скорость быстрого шага
    [SerializeField] float stepHeight = 0.25f; // Высота преодоления ступеней
    [SerializeField] float turnSpeed = 10f;   // Скорость поворота

    public bool Fast { get; private set; }

    bool canMove = true;
    public bool CanMove
    {
        get => canMove;
        set
        {
            canMove = value;
            if (!value) Fast = false; // В раскопе быстрый шаг отключается

            // Отключаем CharacterController во время раскопок, чтобы физика не выталкивала игрока
            if (cc != null) cc.enabled = value;

            // Скрываем/показываем визуальную модель персонажа
            foreach (var r in GetComponentsInChildren<Renderer>(true))
            {
                // Не отключаем рендерер самого корневого объекта капсулы, если он используется как контейнер, 
                // но управляем дочерней 3D-моделью
                if (r.gameObject != gameObject)
                    r.enabled = value;
            }
        }
    }

    CharacterController cc;
    float verticalVel;
    float defaultCenterY;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        cc.stepOffset = stepHeight;
        defaultCenterY = cc.center.y;
    }

    public void ToggleFast()
    {
        if (!canMove) return;
        Fast = !Fast;
    }

    void Update()
    {
        // Если контроллер выключен (например, во время раскопок) или камера не назначена — не двигаемся
        if (!cc.enabled || cam == null) return;

        // Фиксация центра капсулы, чтобы она не «сползала» и не улетала вверх
        Vector3 currentCenter = cc.center;
        currentCenter.y = defaultCenterY;
        cc.center = currentCenter;

        Vector2 input = joystick != null ? joystick.Direction : Vector2.zero;
        if (input == Vector2.zero)
            input = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));

        // Движение относительно направления камеры
        Vector3 fwd = Vector3.ProjectOnPlane(cam.forward, Vector3.up).normalized;
        Vector3 right = Vector3.ProjectOnPlane(cam.right, Vector3.up).normalized;
        Vector3 dir = canMove ? (fwd * input.y + right * input.x) : Vector3.zero;

        if (dir.sqrMagnitude > 1f)
            dir.Normalize();

        float speed = Fast ? fastSpeed : walkSpeed;

        // Гравитация и прижатие к земле
        if (cc.isGrounded)
        {
            verticalVel = -2f; // Небольшое отрицательное значение для стабильного прижимания к полу
        }
        else
        {
            verticalVel -= 9.81f * Time.deltaTime;
        }

        Vector3 moveVector = (dir * speed + Vector3.up * verticalVel) * Time.deltaTime;
        cc.Move(moveVector);

        // Плавный поворот в сторону движения
        if (dir.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(dir);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, turnSpeed * Time.deltaTime);
        }
    }
}